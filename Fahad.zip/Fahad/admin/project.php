<?php
  include_once("custom_functions.php");
  include_once("mysqlconnect.php");
  session_start(); 
  if(!adminloggedin())
    header('Location: ../login.php');
  if(!isset($_GET['id']))
    header('Location: all-projects.php');

  $project = simplequeryrun("SELECT * from projects where id = '".$_GET['id']."'",$conn);
  $type = simplequeryrun("SELECT name from project_types where id='".$project['type_id']."' ",$conn);
  $start_admin = simplequeryrun("SELECT * from admin where id='".$project['start_admin_id']."' ",$conn);

  if (isset($_GET['complete'])) {
    $end_date = date('Y-m-d H:i:s');
    $row = queryrunloop("UPDATE projects set status='completed' where id='".$project['id']."'",$conn);
    $row = queryrunloop("UPDATE projects set end_date='".$end_date."' where id='".$project['id']."'",$conn);
    $row = queryrunloop("UPDATE projects set end_admin_id='".getadminid()."' where id='".$project['id']."'",$conn);
    header('Location:project.php?id='.$project['id']);
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Axis DBS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="css/theme.css" rel="stylesheet">
    <style>
 

  /* Style the search field */
  form.example input[type=text] {
    padding: 10px;
    font-size: 17px;
    border: 1px solid grey;
    float: left;
    width: 80%;
    background: #f1f1f1;
  }

  /* Style the submit button */
  form.example button {
    float: left;
    width: 20%;
    padding: 10px;
    background: #337AB7;
    color: white;
    font-size: 17px;
    border: 1px solid grey;
    border-left: none; /* Prevent double borders */
    cursor: pointer;
  }

  form.example button:hover {
    background: #0b7dda;
  }

  /* Clear floats */
  form.example::after {
    content: "";
    clear: both;
    display: table;
  }
  table {
      border-collapse: collapse;
      border-spacing: 0;
      width: 100%;
      border: 1px solid #ddd;
  }

  th, td {
      text-align: left;
      padding: 8px;
  }

  tr:nth-child(even){background-color: #f2f2f2}

  </style>
</head>
<body>
<nav class="navbar navbar-inverse visible-xs">
 <?php include_once "left-menu.php";?>
    
<div class="col-sm-10">
  <div class="well">
    <h4><a href="index.php">Dashboard</a> > <a href="all-projects.php">All Projects</a> > <?php echo $project['name']; ?></h4>
    <p></p>
  </div>   


<div class="col-sm-3">
  <h1><?php echo $project['name']; ?></h1>
  <p><?php echo $type['name']; ?></p>
  <p><?php echo $project['description']; ?></p>
  <hr>
  <p>Project started on: <?php echo $project['start_date']; ?></p>
  <p>Project started by: <?php echo $start_admin['firstname'].' '.$start_admin['lastname']; ?></p>

</div>
<?php if(!strcmp($project['status'],"active")){ ?>
<a href="add-requirement.php?id=<?php echo $project['id']; ?>"><button type="button" class="btn btn-primary" >Add Requirement</button></a>
<a href="assign_user.php?id=<?php echo $project['id']; ?>"><button type="button" class="btn btn-primary" >Assign User to Project</button></a>
<a href="project.php?id=<?php echo $project['id']; ?>&&complete=true"><button type="button" class="btn btn-primary" >Complete this project</button></a>
</br>
<?php } ?>

<div class="col-sm-6">
  <h1>Requirements</h1>

  <?php
  if(isset($_GET['msg'])){
  if(!strcmp($_GET['msg'],urlencodefuncforerrors("added"))){
  ?>
  <div class="alert alert-success">Requirement added successfully.</div>
  <?php }} ?>

  <table>
    <tr>
      <th>Requirement Name</th>
      <th>No of revisions</th>
      <th>Total comments</th>
      <th>Added by</th>
      <th>Status</th>
    </tr>
    
    <?php
      $no_record = true;
      $project_requirements = queryrunloop("SELECT * from project_requirements WHERE project_id = '".$project['id']."' ORDER BY id DESC",$conn);
      if (mysqli_num_rows($project_requirements) > 0){
          while($row = mysqli_fetch_array($project_requirements, MYSQL_ASSOC)){
            $no_record = false;
            $total_comments = simplequeryrun("SELECT COUNT(id) as total from requirement_comments WHERE requirement_id = '".$row['id']."'",$conn);

            if($row['start_admin_id'] != '0'){
              $admin_name = simplequeryrun("SELECT * from admin where id = '".$row['start_admin_id']."'",$conn);
            }else if($row['start_user_id'] != '0'){
              $user_name = simplequeryrun("SELECT * from users where id = '".$row['start_user_id']."'",$conn);
            }
    ?>

    <tr>
      <td><a href="project-requirement.php?id=<?php echo $row['id']; ?>"><?php echo $row['name']; ?></a></td>
      <td><?php echo $row['revision']; ?></td>
      <td><?php echo $total_comments['total']; ?></td>
      <td><?php if($row['start_admin_id'] != '0'){ echo "Admin: ".$admin_name['firstname'].' '.$admin_name['lastname']; }else if($row['start_user_id'] != '0'){ echo "User: ".$user_name['firstname'].' '.$user_name['lastname']; } ?></td>
      <td><?php echo $row['status']; ?></td>
    </tr>

    <?php }} ?>
  </table>

  <?php if($no_record){ echo '</br><center><div class="alert alert-info">No requirement added yet!</div></center>'; } ?>

</div>

<div class="col-sm-3">
  <h1>User's Assigned</h1>

  <?php
  if(isset($_GET['msg'])){
  if(!strcmp($_GET['msg'],urlencodefuncforerrors("assign"))){
  ?>
  <div class="alert alert-success">User assign successfully.</div>
  <?php }} ?>

  <table>
    <tr>
      <th>Name</th>
      <th>Start Date</th>
    </tr>
    
    <?php
      $no_record = true;
      $project_users = queryrunloop("SELECT * from project_users WHERE project_id = '".$project['id']."' ORDER BY id DESC",$conn);
      if (mysqli_num_rows($project_users) > 0){
          while($row = mysqli_fetch_array($project_users, MYSQL_ASSOC)){
            $no_record = false;
            $users = simplequeryrun("SELECT * from users where id='".$row['user_id']."' ",$conn);
    ?>
    <tr>
      <td><?php echo $users['firstname'].' '.$users['lastname']; ?></td>
      <td><?php echo $row['start_date']; ?></td>
    </tr>

    <?php }} ?>
  </table>

  <?php if($no_record){ echo '</br><center><div class="alert alert-info">No user assigned yet!</div></center>'; } ?>


</div>


</div>
</body>
</html>
