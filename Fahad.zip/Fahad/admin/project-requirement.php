<?php
  include_once("custom_functions.php");
  include_once("mysqlconnect.php");
  session_start(); 
  if(!adminloggedin())
    header('Location: ../login.php');

  if(!isset($_GET['id']))
    header('Location: all-projects.php');

  $project_requirements = simplequeryrun("SELECT * from project_requirements where id = '".$_GET['id']."'",$conn);
  $project = simplequeryrun("SELECT * from projects where id = '".$project_requirements['project_id']."'",$conn);
  $type = simplequeryrun("SELECT name from project_types where id='".$project['type_id']."' ",$conn);

  if (isset($_GET['complete'])) {
    $end_date = date('Y-m-d H:i:s');
    $row = queryrunloop("UPDATE project_requirements set status='completed' where id='".$project_requirements['id']."'",$conn);
    header('Location:project-requirement.php?id='.$project_requirements['id']);
  }
  if (isset($_GET['revision'])) {
    $revision = $project_requirements['revision'] + 1;
    $row = queryrunloop("UPDATE project_requirements set revision='".$revision."' where id='".$project_requirements['id']."'",$conn);
    $row = queryrunloop("UPDATE project_requirements set status='active' where id='".$project_requirements['id']."'",$conn);
    $row = queryrunloop("UPDATE project_requirements set end_date='' where id='".$project_requirements['id']."'",$conn);
    $row = queryrunloop("UPDATE project_requirements set end_admin_id='0' where id='".$project_requirements['id']."'",$conn);
    header('Location:project-requirement.php?id='.$project_requirements['id']);
  }
  if (isset($_GET['supplier'])) {
    $revision = $project_requirements['revision'] + 1;
    $end_date = date('Y-m-d H:i:s');
    $row = queryrunloop("UPDATE project_requirements set status='finished' where id='".$project_requirements['id']."'",$conn);
    $row = queryrunloop("UPDATE project_requirements set end_date='".$end_date."' where id='".$project_requirements['id']."'",$conn);
    $row = queryrunloop("UPDATE project_requirements set end_admin_id='".getadminid()."' where id='".$project_requirements['id']."'",$conn);
    header('Location:project-requirement.php?id='.$project_requirements['id']);
  }

  if(isset($_POST['supplier_submit'])){
    $supplier_id = $_POST['supplier_id'];
    $date = date('Y-m-d H:i:s');
    $row = queryrunloop("UPDATE project_requirements set supplier_id='".$supplier_id."' where id='".$project_requirements['id']."'",$conn);
    $row = queryrunloop("UPDATE project_requirements set supplier_date='".$date."' where id='".$project_requirements['id']."'",$conn);
    $row = queryrunloop("UPDATE project_requirements set status='supplier' where id='".$project_requirements['id']."'",$conn);
    header('Location:project-requirement.php?id='.$project_requirements['id']);
  }
  
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Axis DBS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="css/theme.css" rel="stylesheet">
    <style>
 

  /* Style the search field */
  form.example input[type=text] {
    padding: 10px;
    font-size: 17px;
    border: 1px solid grey;
    float: left;
    width: 80%;
    background: #f1f1f1;
  }

  /* Style the submit button */
  form.example button {
    float: left;
    width: 20%;
    padding: 10px;
    background: #337AB7;
    color: white;
    font-size: 17px;
    border: 1px solid grey;
    border-left: none; /* Prevent double borders */
    cursor: pointer;
  }

  form.example button:hover {
    background: #0b7dda;
  }

  /* Clear floats */
  form.example::after {
    content: "";
    clear: both;
    display: table;
  }
  table {
      border-collapse: collapse;
      border-spacing: 0;
      width: 100%;
      border: 1px solid #ddd;
  }

  th, td {
      text-align: left;
      padding: 8px;
  }

  tr:nth-child(even){background-color: #f2f2f2}

  .registerbtn {
    background-color: #337AB7;
    color: white;
    padding: 16px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}
.registerbtn:hover {
    opacity: 1;
}

  </style>


</head>
<body>
<nav class="navbar navbar-inverse visible-xs">
 <?php include_once "left-menu.php";?>
    
<div class="col-sm-10">
  <div class="well">
    <h4><a href="index.php">Dashboard</a> > <a href="all-projects.php">All Projects</a> > <a href="project.php?id=<?php echo $project['id']; ?>"><?php echo $project['name']; ?></a> > <?php echo $project_requirements['name']; ?></h4>
    <p></p>
  </div>   


<div class="col-sm-4">
  <h1><?php echo $project['name']; ?></h1>
  <p><?php echo $type['name']; ?></p>
  <p><?php echo $project['description']; ?></p>

  <hr>

  <h1><?php echo $project_requirements['name']; ?></h1>
  <p><?php echo $project_requirements['description']; ?></p>

  <hr>
  <center>
  <?php if(!strcmp($project['status'],"active")){ if(!strcmp($project_requirements['status'],'active')){ ?>
  <a href="project-requirement.php?id=<?php echo $_GET['id']; ?>&&complete=true"><button type="button" class="btn btn-primary" >Complete this requirement</button></a>
  <?php }else if(!strcmp($project_requirements['status'],'completed')){ ?>

  <form action="project-requirement.php?id=<?php echo $_GET['id']; ?>" method="POST" enctype="multipart/form-data">
  <select class="form-control" name="supplier_id">
    <?php
    $suppliers = queryrunloop("SELECT * from suppliers ORDER BY firstname",$conn);
    if (mysqli_num_rows($suppliers) > 0){
        while($row = mysqli_fetch_array($suppliers, MYSQL_ASSOC)){
    ?>
    <option value="<?php echo $row['id']; ?>"><?php echo $row['firstname'].' '.$row['lastname']; ?></option>
    <?php }} ?>
  </select>
  <br>
  <button type="submit" name="supplier_submit" class="registerbtn">Assign Supplier</button>
  </form>
  <?php  }else if(!strcmp($project_requirements['status'],'supplier')){ ?>

    <?php $supplier = simplequeryrun("SELECT * from suppliers where id = '".$project_requirements['supplier_id']."'",$conn); ?>
    <h5><?php echo "Assigned to supplier: ".$supplier['firstname'].' '.$supplier['lastname']; ?></h5>
    <hr>
    <a href="project-requirement.php?id=<?php echo $_GET['id']; ?>&&supplier=true"><button type="button" class="btn btn-primary" >Finish this requirement</button></a>

  <?php }else{ ?>
  <a href="project-requirement.php?id=<?php echo $_GET['id']; ?>&&revision=true"><button type="button" class="btn btn-primary" >Add a revision</button></a>
  <?php } } ?>
  </center>
  </br>

</div>

<div class="col-sm-8">
  <h1>Comments</h1>

  <?php
  $version = 100000;
  $no_record = true;
  $comments = queryrunloop("SELECT * from requirement_comments WHERE requirement_id = '".$project_requirements['id']."' ORDER BY id DESC",$conn);
  if (mysqli_num_rows($comments) > 0){
      while($row = mysqli_fetch_array($comments, MYSQL_ASSOC)){
        $no_record = false;
        if($row['user_id'] != 0){
          $user = simplequeryrun("SELECT * from users where id='".$row['user_id']."' ",$conn);
          $name = $user['firstname'].' '.$user['lastname'];
        }
        else{
          $supplier = simplequeryrun("SELECT * from suppliers where id='".$row['supplier_id']."' ",$conn);
          $name = $supplier['firstname'].' '.$supplier['lastname'];
        }
  ?>
  <?php if($row['revision'] < $version){ $version = $row['revision']; $vp = $version + 1;  echo '<hr><center><h3>Revision # '.$version.'</h3></center>'; } ?>
  <hr>
  <p><?php if($row['user_id'] != 0) echo "<b>User: </b>"; else echo "<b>Supplier: </b>"; echo $name.' added a comment on: '.$row['date_time']; ?></p>
  <div class="row">
  <div class="col-sm-3">
    <h4><?php echo $row['title']; ?></h4>
    <?php if(strcmp($row['file'],"")){ ?>
    <p>File Attached: <a href="<?php echo '../'.$row['file']; ?>" target="_blank"><?php echo $row['filename']; ?></a></p>
    <?php } ?>
  </div>
  <div class="col-sm-9">
    <p><?php echo $row['comment']; ?></p>
  </div>
  </div>
  
  <?php }} ?>
  <?php if($no_record){ echo '</br><center><div class="alert alert-info">No comment added yet!</div></center>'; } ?>
  <hr>
</div>


</div>
</body>
</html>
